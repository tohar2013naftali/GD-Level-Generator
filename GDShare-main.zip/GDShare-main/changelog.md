
## v1.6.0
 * Allow exporting multiple levels, thanks to @RayDeeUx
 * Allow importing old formats, thanks to @FijiAura
 * Support for 2.2081

## v1.5.0
 * Mac & iOS support!

## v1.4.2
 * Exports lists (.gmdl) button

## v1.4.1
 * Update Geode version

# v1.4.0
 * Add 2.2074 support (except for Mac :c)

# v1.3.2
 * Fix import button in My Lists being misplaced pt. 2

# v1.3.1
 * Fix import button in My Lists being misplaced

# v1.3.0
 * Add import button to My Lists
 * Add support for Intel MacOS

# v1.2.0
 * Add support for 2.206

# v1.1.0
 * Add support for importing/exporting lists as `.gmdl` files
 * Allow importing multiple levels at once

